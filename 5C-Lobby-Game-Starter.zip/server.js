const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "";

app.use(express.static("public"));

const rooms = new Map();
function roomFor(name) {
  if (!rooms.has(name)) rooms.set(name, new Map());
  return rooms.get(name);
}
function safeText(value, max = 180) {
  return String(value || "").replace(/[<>]/g, "").trim().slice(0, max);
}

io.on("connection", socket => {
  socket.on("join", data => {
    const room = safeText(data && data.room, 24) || "Main Lobby";
    const name = safeText(data && data.name, 18) || "Player";
    if (socket.data.room) socket.leave(socket.data.room);
    socket.data.room = room;
    socket.data.name = name;
    socket.join(room);
    roomFor(room).set(socket.id, { name });
    socket.emit("joined", { room, name });
    io.to(room).emit("notice", `${name} joined ${room}.`);
    io.to(room).emit("players", [...roomFor(room).values()]);
  });

  socket.on("chat", raw => {
    const message = safeText(raw, 180);
    if (!message || !socket.data.room) return;
    io.to(socket.data.room).emit("chat", {
      name: socket.data.name || "Player",
      message,
      time: new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"})
    });
  });

  socket.on("admin", data => {
    if (!ADMIN_TOKEN || !data || data.token !== ADMIN_TOKEN) {
      socket.emit("adminResult", { ok: false, message: "Admin access is not configured or the token is incorrect." });
      return;
    }
    const message = safeText(data.message, 180);
    if (!message) return;
    io.emit("announcement", message);
    socket.emit("adminResult", { ok: true, message: "Announcement sent." });
  });

  socket.on("disconnect", () => {
    const room = socket.data.room;
    if (!room || !rooms.has(room)) return;
    roomFor(room).delete(socket.id);
    io.to(room).emit("notice", `${socket.data.name || "A player"} left.`);
    io.to(room).emit("players", [...roomFor(room).values()]);
  });
});

server.listen(PORT, () => console.log(`5C LOBBY running on port ${PORT}`));
