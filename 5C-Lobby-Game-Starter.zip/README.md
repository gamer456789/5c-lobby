# 5C LOBBY — starter project

This is a small browser-based multiplayer prototype. It runs on laptops, tablets and phones with a modern browser.

## Run it on your computer
1. Install Node.js (version 18 or newer).
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

## Deploy
Use a Node.js hosting service that supports WebSockets.
- Build/install command: `npm install`
- Start command: `npm start`
- Set the environment variable `ADMIN_TOKEN` to a long private value.
- Do not share your admin token publicly.

## Important
This is an early prototype, not a finished production game. It has basic movement, room chat and a server-checked announcement command. It does not yet include user accounts, persistent data, full moderation, or a complete 3D world. Use a trusted host and moderate chat carefully, especially if children will use it. Never publish private information in chat.
